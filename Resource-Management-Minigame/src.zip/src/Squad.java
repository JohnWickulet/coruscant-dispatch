import java.util.ArrayList;
import java.util.List;

public class Squad {

    public List<Soldier> soldiers;
    public Inventory inventory;

    public Squad(int capacity) {
        soldiers = new ArrayList<>(capacity);
        inventory = new Inventory();
    }

    public void addSoldier(Soldier s) {
        soldiers.add(s);
    }
}
