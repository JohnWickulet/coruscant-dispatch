import javax.swing.*;
import java.awt.*;

public class UpgradeWindow extends GameWindow implements UpgradeListener {

    private final Squad squad;
    private Soldier activeSoldier;

    private JPanel centerPanel;
    private JPanel selectorPanel;

    public UpgradeWindow(Window owner, Squad squad) {
        super(owner, "Upgrade Troopers", 900, 550);
        this.squad = squad;
        this.activeSoldier = squad.soldiers.get(0);

        setLayout(new BorderLayout(10, 10));
        setBackground(new Color(30, 30, 30));

        centerPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        refreshCenter();

        selectorPanel = createSelectorPanel();

        add(centerPanel, BorderLayout.CENTER);
        add(selectorPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void refreshCenter() {
        centerPanel.removeAll();

        centerPanel.add(new SoldierInfoPanel(activeSoldier));
        centerPanel.add(new UpgradePanel(activeSoldier, this));
        centerPanel.add(new StatPentagonPanel(activeSoldier));

        centerPanel.revalidate();
        centerPanel.repaint();
    }

    private JPanel createSelectorPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        panel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.DARK_GRAY));

        for (Soldier s : squad.soldiers) {
            JButton btn = new JButton(s.name);
            btn.setPreferredSize(new Dimension(90, 60));

            if (s.exp >= s.getExpToLevel()) {
                btn.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 3));
            }

            btn.addActionListener(e -> {
                activeSoldier = s;
                refreshCenter();
                refreshSelector();
            });

            panel.add(btn);
        }
        return panel;
    }

    private void refreshSelector() {
        remove(selectorPanel);
        selectorPanel = createSelectorPanel();
        add(selectorPanel, BorderLayout.SOUTH);
        revalidate();
        repaint();
    }

    @Override
    public void onUpgrade() {
        refreshCenter();
        refreshSelector();
    }
}
