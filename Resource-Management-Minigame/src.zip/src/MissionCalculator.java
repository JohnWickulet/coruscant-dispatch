public class MissionCalculator {

    public static double calculateSuccessRate(
            Event event,
            java.util.List<Soldier> team
    ) {
        if (team.isEmpty()) return 0;

        double strength = 0, mobility = 0, intel = 0, stealth = 0, charisma = 0;

        for (Soldier s : team) {
            strength += s.strength;
            mobility += s.mobility;
            intel += s.intelligence;
            stealth += s.stealth;
            charisma += s.charisma;
        }

        int size = team.size();

        strength /= size;
        mobility /= size;
        intel /= size;
        stealth /= size;
        charisma /= size;

        double score =
                strength * event.reqStrength +
                        mobility * event.reqMobility +
                        intel * event.reqIntelligence +
                        stealth * event.reqStealth +
                        charisma * event.reqCharisma;

        double maxScore =
                10.0 * (
                        event.reqStrength +
                                event.reqMobility +
                                event.reqIntelligence +
                                event.reqStealth +
                                event.reqCharisma
                );

        return score / maxScore; // 0.0 → 1.0
    }
}
