import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ItemCard extends JPanel {

    private final Resource resource;
    private final GameUI ui;

    private final JLabel qtyLabel;

    public ItemCard(Resource resource, GameUI ui) {
        this.resource = resource;
        this.ui = ui;

        setPreferredSize(new Dimension(180, 130));
        setLayout(new BorderLayout(5, 5));
        setBorder(new LineBorder(Color.GRAY, 2));
        setBackground(new Color(240, 240, 240));

        JLabel nameLabel = new JLabel(resource.name);
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        qtyLabel = new JLabel("Qty: " + resource.quantity);
        qtyLabel.setFont(new Font("Arial", Font.PLAIN, 12));

        JTextArea desc = new JTextArea(resource.description);
        desc.setEditable(false);
        desc.setLineWrap(true);
        desc.setWrapStyleWord(true);
        desc.setOpaque(false);
        desc.setFont(new Font("Arial", Font.PLAIN, 11));

        add(nameLabel, BorderLayout.NORTH);
        add(qtyLabel, BorderLayout.CENTER);
        add(desc, BorderLayout.SOUTH);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                openActionDialog();
            }
        });
    }

    private void openActionDialog() {
        String[] options = {"Use", "Discard", "Cancel"};

        int choice = JOptionPane.showOptionDialog(
                ui,
                "What do you want to do with " + resource.name + "?",
                "Inventory",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
        );

//        if (choice == 0) {
//            ui.useItem(resource);
//        } else if (choice == 1) {
//            ui.discardItem(resource);
//        }
    }

    public void refresh() {
        qtyLabel.setText("Qty: " + resource.quantity);
    }
}
