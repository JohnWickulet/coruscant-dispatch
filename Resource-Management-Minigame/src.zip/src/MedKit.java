public class MedKit extends Resource {

    public MedKit() {
        name = "Med Kit";
        description = "Restores 4 health";
        quantity = 1;
    }

    @Override
    public void use(Soldier s) {
        s.health = Math.min(s.maxHealth, s.health + 4);
    }
}
