import java.util.List;
import java.util.Random;

public abstract class Event {

    public enum State {
        AVAILABLE,
        IN_PROGRESS,
        RESOLVED,
        EXPIRED
    }

    public String name;
    public String description;

    public int duration;     // total duration
    public int timeLeft;     // countdown
    public int maxDeploy;
    public int checks_required;

    // Stat requirements
    public int reqStrength;
    public int reqMobility;
    public int reqIntelligence;
    public int reqStealth;
    public int reqCharisma;

    protected List<Soldier> deployed;
    protected State state = State.AVAILABLE;
    private static final Random rand = new Random();

    /* ================= DEPLOY ================= */

    public void deploy(List<Soldier> soldiers) {
        this.deployed = soldiers;
        this.state=State.IN_PROGRESS;
        this.timeLeft=this.duration;
        for (Soldier s : deployed) {
            s.startMission();
        }
    }

    /* ================= TICK ================= */

    public void tick() {
        if(timeLeft>0) timeLeft--;
        if(timeLeft==0 && state==State.AVAILABLE) state=State.EXPIRED;
    }
    protected void resolve() {
        if(state!=State.IN_PROGRESS) return;
        int check_success=0;
        if (reqStrength > 0) {
            int roll = rand.nextInt(reqStrength + 1);
            int sum = statSum(Stat.STRENGTH);
            if (sum >= roll) check_success++;
        }
        if (reqCharisma > 0) {
            int roll = rand.nextInt(reqCharisma + 1);
            int sum = statSum(Stat.CHARISMA);
            if (sum >= roll) check_success++;
        }
        if (reqIntelligence > 0) {
            int roll = rand.nextInt(reqIntelligence + 1);
            int sum = statSum(Stat.INTELLIGENCE);
            if (sum >= roll) check_success++;
        }
        if (reqMobility > 0) {
            int roll = rand.nextInt(reqMobility + 1);
            int sum = statSum(Stat.MOBILITY);
            if (sum >= roll) check_success++;
        }
        if (reqStealth > 0) {
            int roll = rand.nextInt(reqStealth + 1);
            int sum = statSum(Stat.STEALTH);
            if (sum >= roll) check_success++;
        }
        boolean success = check_success>=checks_required;

        if (success) onSuccess(deployed);
        else onFailure(deployed);
        for(Soldier s:deployed){
            s.endMission();
        }
        state = State.RESOLVED;
    }

    public int statSum(Stat stat){
        int sum=0;
        for(Soldier s:deployed){
            switch(stat){
                case STRENGTH:sum+=s.strength;break;
                case MOBILITY:sum+=s.mobility;break;
                case INTELLIGENCE:sum+=s.intelligence;break;
                case STEALTH:sum+=s.stealth;break;
                case CHARISMA:sum+=s.charisma;break;
            }
        }
        return sum;
    }

    public abstract void onSuccess(List<Soldier> deployed);
    public abstract void onFailure(List<Soldier> deployed);
}
