public enum MissionResult {
    SUCCESS,
    FAILURE
}
