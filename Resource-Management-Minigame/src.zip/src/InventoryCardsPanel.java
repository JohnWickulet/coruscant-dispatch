import javax.swing.*;
import java.awt.*;

public class InventoryCardsPanel extends JPanel {

    private final Inventory inventory;
    private final GameUI ui;

    public InventoryCardsPanel(Inventory inventory, GameUI ui) {
        this.inventory = inventory;
        this.ui = ui;

        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
        refresh();
    }

    public void refresh() {
        removeAll();

        for (Resource r : inventory.getItems()) {
            if (r.quantity > 0) {
                add(new ItemCard(r, ui));
            }
        }

        revalidate();
        repaint();
    }
}
