import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Game {

    public Squad squad;
    public int day;

    private List<Event> activeEvents;
    private Random rng;

    public Game() {
        squad = new Squad(10);
        activeEvents = new ArrayList<>();
        rng = new Random();
        day = 1;
    }

    /* ===============================
       INITIAL SETUP
       =============================== */

    public void initialize() {

        // Starter Stormtroopers (5-stat system)
        squad.addSoldier(new StormTrooper("TK-421"));
        squad.addSoldier(new StormTrooper("FN-2187"));
        squad.addSoldier(new StormTrooper("CT-9904"));

        // Starter inventory

        day = 1;
    }


    public void tick(){
        for(Event e:activeEvents){
            e.tick();
        }
        for(Soldier s:squad.soldiers){
            s.tick();
        }
    }


    /* ===============================
       EVENT MANAGEMENT
       =============================== */

    public void addEvent(Event event) {
        activeEvents.add(event);
    }

    public void removeEvent(Event event) {
        activeEvents.remove(event);
    }

    public List<Event> getActiveEvents() {
        return Collections.unmodifiableList(activeEvents);
    }

    /* ===============================
       EVENT RESOLUTION (DISPATCH STYLE)
       =============================== */

    public MissionResult resolveEvent(Event event, List<Soldier> deployed) {

        if (deployed == null || deployed.isEmpty()) {
            event.onFailure(deployed);
            removeEvent(event);
            advanceDay();
            return MissionResult.FAILURE;
        }

        double successChance =
                calculateSuccessRate(event, deployed);

        boolean success = rng.nextDouble() < successChance;

        if (success) {
            event.onSuccess(deployed);
        } else {
            applyFailureDamage(deployed);
                event.onFailure(deployed);
        }

        removeEvent(event);
        advanceDay();

        return success
                ? MissionResult.SUCCESS
                : MissionResult.FAILURE;
    }

    /* ===============================
       SUCCESS CALCULATION
       =============================== */

    private double calculateSuccessRate(
            Event event,
            List<Soldier> team
    ) {

        double str = 0, mob = 0, intel = 0, stl = 0, cha = 0;

        for (Soldier s : team) {
            str += s.strength;
            mob += s.mobility;
            intel += s.intelligence;
            stl += s.stealth;
            cha += s.charisma;
        }

        double weightedScore =
                str * event.reqStrength +
                        mob * event.reqMobility +
                        intel * event.reqIntelligence +
                        stl * event.reqStealth +
                        cha * event.reqCharisma;

        double maxScore =
                10.0 * (
                        event.reqStrength +
                                event.reqMobility +
                                event.reqIntelligence +
                                event.reqStealth +
                                event.reqCharisma
                );

        if (maxScore == 0) return 1.0;

        // Clamp to avoid guaranteed outcomes
        double raw = weightedScore / maxScore;
        return Math.max(0.05, Math.min(0.95, raw));
    }

    /* ===============================
       FAILURE CONSEQUENCES
       =============================== */

    private void applyFailureDamage(List<Soldier> team) {
        for (Soldier s : team) {
            s.health --;
            if (s.health < 0) {
                s.health = 0;
            }
        }
    }

    /* ===============================
       TIME PROGRESSION
       =============================== */

    private void advanceDay() {
        day++;
    }
}
