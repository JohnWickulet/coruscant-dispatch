import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class SoldierSelectionPanel extends JPanel {

    private final List<SoldierCard> cards = new ArrayList<>();
    private final int maxSelectable = 10;
    private boolean selectionEnabled = false;

    public SoldierSelectionPanel(Squad squad) {
        setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
        setBorder(BorderFactory.createTitledBorder("Troops"));
        setPreferredSize(new Dimension(0, 140));

        for (Soldier s : squad.soldiers) {
            if (s.health <= 0) continue;

            SoldierCard card = new SoldierCard(s);
            cards.add(card);

            card.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    if (!selectionEnabled) return;
                    toggle(card);
                }
            });

            add(card);
        }
    }

    /* ===== MODE CONTROL ===== */

    public void enableSelection() {
        selectionEnabled = true;
        setBorder(BorderFactory.createTitledBorder("Select Troops"));
    }

    public void disableSelection() {
        selectionEnabled = false;
        clearSelection();
        setBorder(BorderFactory.createTitledBorder("Troops"));
    }

    /* ===== SELECTION LOGIC ===== */

    private void toggle(SoldierCard card) {
        if (!card.isSelected() && getSelectedSoldiers().size() >= maxSelectable) {
            JOptionPane.showMessageDialog(
                    this,
                    "You can select up to " + maxSelectable + " troops.",
                    "Limit",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }
        card.toggle();
        repaint();
    }

    public void clearSelection() {
        for (SoldierCard c : cards) {
            c.toggle();
        }
    }

    public List<Soldier> getSelectedSoldiers() {
        List<Soldier> selected = new ArrayList<>();
        for (SoldierCard c : cards) {
            if (c.isSelected()) selected.add(c.getSoldier());
        }
        return selected;
    }
}
