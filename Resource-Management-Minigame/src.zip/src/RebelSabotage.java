import java.util.List;

public class RebelSabotage extends Event {
    public RebelSabotage() {
        name = "Rebel Sabotage";
        description = "Rebels attempting to destroy a supply depot";
        timeLeft = 20;        // countdown before mission expires
        maxDeploy = 2;        // max soldiers allowed
        reqStrength = 3;
        reqMobility = 4;
        reqIntelligence = 2;
        reqStealth = 0;
        reqCharisma = 0;
        duration = 10;        // how long mission takes once deployed
    }

    // Called when player deploys soldiers

    @Override
    public void onSuccess(List<Soldier> deployed) {
        for (Soldier s : deployed) {
            s.exp += 20;
        }
    }
    @Override
    public void onFailure(List<Soldier> deployed) {
        // Optional: add penalties or notifications
    }
}
