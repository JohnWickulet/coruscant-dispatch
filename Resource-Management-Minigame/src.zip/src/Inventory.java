import java.util.ArrayList;
import java.util.List;

public class Inventory {

    private final List<Resource> items = new ArrayList<>();

    public void add(Resource r) {
        for (Resource item : items) {
            if (item.name.equals(r.name)) {
                item.quantity += r.quantity;
                return;
            }
        }
        items.add(r);
    }

    public List<Resource> getItems() {
        return items;
    }
}
