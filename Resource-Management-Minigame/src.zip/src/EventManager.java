import javax.swing.*;

public class EventManager {

    private Timer tickTimer;
    private Timer spawnTimer;

    public EventManager(GalaxyMapPanel map, GameUI ui) {

        // Event tick timer
        tickTimer = new Timer(1000, e -> map.tick());
        tickTimer.start();

        // Event spawn timer
        spawnTimer = new Timer(8000, e -> map.addEvent(new EventCard(new RebelSabotage())));
        spawnTimer.start();
    }

    // Pause both timers
    public void pause() {
        tickTimer.stop();
        spawnTimer.stop();
    }

    // Resume both timers
    public void resume() {
        tickTimer.start();
        spawnTimer.start();
    }
}
