import javax.swing.*;
import java.awt.*;

public class EventCard extends JLabel {

    public final Event event;

    public EventCard(Event event) {
        this.event = event;
        setText("<html><b>" + event.name + "</b></html>");
        setOpaque(true);
        setBackground(new Color(200, 50, 50, 180));
        setForeground(Color.WHITE);
        setHorizontalAlignment(SwingConstants.CENTER);
        setBorder(BorderFactory.createLineBorder(Color.BLACK));
        setSize(120, 50);
    }

    public void tick() {
        event.tick();
        updateDisplay();
    }

    private void updateDisplay() {
        if (event.state == Event.State.AVAILABLE) {
            setText("<html><b>" + event.name + "</b><br>Time: " + event.timeLeft + "</html>");
        } else if (event.state == Event.State.IN_PROGRESS) {
            setText("<html><b>" + event.name + "</b><br>Mission: " + event.timeLeft + "</html>");
        } else if (event.state == Event.State.EXPIRED) {
            setText("<html><b>" + event.name + "</b><br>Expired</html>");
            setBackground(Color.GRAY);
        } else if (event.state == Event.State.RESOLVED) {
            setText("<html><b>" + event.name + "</b><br>Resolved</html>");
            setBackground(new Color(50, 200, 50, 180));
        }
    }
}
