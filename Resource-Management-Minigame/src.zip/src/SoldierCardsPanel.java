import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

class SoldierCardsPanel extends JPanel {
    private final java.util.List<SoldierCard> cards = new ArrayList<>();
    private final java.util.List<SoldierSelectionListener> listeners = new ArrayList<>();

    public SoldierCardsPanel(Squad squad) {
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));

        for (Soldier s : squad.soldiers) {
            if (s.health <= 0) continue;
            SoldierCard card = new SoldierCard(s);
            cards.add(card);

            card.addMouseListener(new java.awt.event.MouseAdapter() {
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    card.toggle();
                    notifySelectionChanged();
                }
            });
            add(card);
        }
    }

    public java.util.List<Soldier> getSelectedSoldiers() {
        List<Soldier> list = new ArrayList<>();
        for (SoldierCard c : cards)
            if (c.isSelected())
                list.add(c.getSoldier());
        return list;
    }

    public void addSelectionListener(SoldierSelectionListener listener) {
        listeners.add(listener);
    }

    private void notifySelectionChanged() {
        for (SoldierSelectionListener l : listeners)
            l.selectionChanged();
    }
    }