import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GalaxyMapPanel extends JPanel {

    private final List<EventCard> events = new ArrayList<>();

    public GalaxyMapPanel() {
        setLayout(null);
        setBackground(new Color(5, 5, 30)); // space background
    }

    public void addEvent(EventCard e) {
        e.setLocation((int) (Math.random() * 600), (int) (Math.random() * 300));
        events.add(e);
        add(e);

        // Click listener for resolving or deploying
        e.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent ev) {
                Event evt = e.event;

                // If available, open deployment dialog
                if (evt.state == Event.State.AVAILABLE) {
                    GameUI parent = (GameUI) SwingUtilities.getWindowAncestor(GalaxyMapPanel.this);
                    parent.openDeploymentDialog(evt);
                }
                // If deployed and duration is over, resolve manually
                else if (evt.state == Event.State.IN_PROGRESS && evt.timeLeft <= 0) {
                    evt.resolve();
                    e.updateUI();
                }
            }
        });

        repaint();
    }

    public void tick() {
        Iterator<EventCard> it = events.iterator();
        while (it.hasNext()) {
            EventCard e = it.next();
            e.tick();

            // Remove expired events
            if (e.event.state == Event.State.EXPIRED) {
                remove(e);
                it.remove();
            }
        }
        repaint();
    }

    public void removeEvent(Event event) {
        Iterator<EventCard> it = events.iterator();
        while (it.hasNext()) {
            EventCard e = it.next();
            if (e.event == event) {
                remove(e);
                it.remove();
            }
        }
        repaint();
    }
}
