import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class SoldierCard extends JPanel {

    private final Soldier soldier;
    private boolean selected = false;

    private SoldierStatsPopup popup;

    public SoldierCard(Soldier soldier) {
        this.soldier = soldier;

        setPreferredSize(new Dimension(120, 150));
        setLayout(new BorderLayout());
        setBorder(new LineBorder(Color.GRAY, 2));
        setBackground(Color.WHITE);

        JLabel name = new JLabel(soldier.name, SwingConstants.CENTER);
        name.setFont(name.getFont().deriveFont(Font.BOLD));

        JLabel image = new JLabel(soldier.portrait, SwingConstants.CENTER);
        Image img = soldier.portrait.getImage();
        Image scaled = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        image.setIcon(new ImageIcon(scaled));

        add(image, BorderLayout.CENTER);
        add(name, BorderLayout.SOUTH);

    }

    private Icon loadImage() {
        // Fallback icon (replace with real image later)
        return UIManager.getIcon("OptionPane.informationIcon");
    }

    public Soldier getSoldier() {
        return soldier;
    }

    public boolean isSelected() {
        return selected;
    }

    public void toggle() {
        selected = !selected;
        setBorder(new LineBorder(selected ? Color.GREEN : Color.GRAY, 3));
        repaint();
    }


}
