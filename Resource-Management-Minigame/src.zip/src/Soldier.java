import javax.swing.*;
import java.awt.*;

public abstract class Soldier {

    public enum State {AVAILABLE, DEPLOYED, RESTING}

    public String name;

    // Stats (0–10)
    public int strength;
    public int mobility;
    public int intelligence;
    public int stealth;
    public int charisma;
    public State state=State.AVAILABLE;
    public int health;
    public int maxHealth;
    public int exp;
    public int level;
    public int rest_time;
    public int rest_time_remaining;
    public ImageIcon portrait;



    public Soldier(
            String name,
            int strength,
            int mobility,
            int intelligence,
            int stealth,
            int charisma,
            int rest_time,
            String imagePath
    ) {
        this.name = name;
        this.strength = clamp(strength);
        this.mobility = clamp(mobility);
        this.intelligence = clamp(intelligence);
        this.stealth = clamp(stealth);
        this.charisma = clamp(charisma);
        this.rest_time = rest_time;
        this.maxHealth = 2;
        this.health = maxHealth;
        this.exp = 0;
        this.level = 1;
        this.portrait = new ImageIcon(getClass().getResource(imagePath));
    }

    private int clamp(int v) {
        return Math.max(0, Math.min(10, v));
    }

    public int getExpToLevel() {
        return 10 + level * 5; // example scaling
    }

    public void increaseStat(String stat) {
        switch (stat) {
            case "Strength":
                strength++;
                break;
            case "Mobility":
                mobility++;
                break;
            case "Intelligence":
                intelligence++;
                break;
            case "Stealth":
                stealth++;
                break;
            case "Charisma":
                charisma++;
                break;
        }
        level++;
    }
    public int getStat(Stat stat) {
        return switch (stat) {
            case STRENGTH -> strength;
            case MOBILITY -> mobility;
            case INTELLIGENCE -> intelligence;
            case STEALTH -> stealth;
            case CHARISMA -> charisma;
        };
    }
    public boolean isAvailable(){
        return state==State.AVAILABLE;
    }
    public void startMission() {
        state = State.DEPLOYED;
        rest_time_remaining = 0;
    }
    public void endMission() {
        state = State.RESTING;
        rest_time_remaining = rest_time;
    }
    public void tick(){
        if(state == State.RESTING){
            rest_time_remaining--;
            if(rest_time_remaining<=0){
                state=State.AVAILABLE;
                rest_time_remaining=0;
            }
        }
    }
}
