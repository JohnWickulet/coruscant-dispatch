import javax.swing.*;
import java.awt.*;

public class GameUI extends JFrame {

    Game game;
    GalaxyMapPanel map;
    BottomPanel bottomPanel;
    Timer tickTimer; // automatic tick
    EventManager eventManager;

    public GameUI() {
        setTitle("Star Wars Dispatch-like Game");
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Initialize game
        game = new Game();
        game.initialize();

        // Galaxy map panel
        map = new GalaxyMapPanel();
        add(map, BorderLayout.CENTER);

        // Bottom panel with troops, shop, upgrades
        bottomPanel = new BottomPanel(game, this);
        add(bottomPanel, BorderLayout.SOUTH);

        // Event manager (optional, for spawning)
        eventManager = new EventManager(map, this);

        // Start automatic ticking every second
        startTicking();

        setVisible(true);
    }

    /* ================= AUTOMATIC TICK ================= */
    private void startTicking() {
        tickTimer = new Timer(1000, e -> {
            game.tick();
        });
        tickTimer.start();
    }

    /* ================= DEPLOYMENT ================= */
    // Called when player clicks an available event on map
    public void openDeploymentDialog(Event event) {
        pauseGame();
        DeploymentDialog dialog = new DeploymentDialog(this, game.squad, event);
        // Make dialog modal-like over map (optional: not a separate JFrame)
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
        resumeGame();
    }

    private void pauseGame() {
        if (eventManager != null) eventManager.pause();
        if (tickTimer != null) tickTimer.stop();
    }

    private void resumeGame() {
        if (eventManager != null) eventManager.resume();
        if (tickTimer != null) tickTimer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameUI::new);
    }
}
