public class StormTrooper extends Soldier {

    public StormTrooper(String name) {
        super(
                name,
                1,  // strength
                1,  // mobility
                1,  // intelligence
                1,  // stealth
                1,   // charisma
                10,
                "tumf.jpg"
        );
    }
}
