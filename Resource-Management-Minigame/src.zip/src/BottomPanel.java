import javax.swing.*;
import java.awt.*;

public class BottomPanel extends JPanel {

    public BottomPanel(Game game, GameUI ui) {
        setLayout(new BorderLayout());

        // Menu buttons
        JPanel menuPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton inventoryBtn = new JButton("Inventory");
        JButton shopBtn = new JButton("Shop");
        JButton upgradeBtn = new JButton("Upgrades");

//        inventoryBtn.addActionListener(e ->
//                new InventoryWindow(ui, game.squad.inventory));
//
//        shopBtn.addActionListener(e ->
//                new ShopWindow(ui, game));

        upgradeBtn.addActionListener(e ->
                new UpgradeWindow(ui, game.squad));

        menuPanel.add(inventoryBtn);
        menuPanel.add(shopBtn);
        menuPanel.add(upgradeBtn);

        add(menuPanel, BorderLayout.CENTER);
    }
}
